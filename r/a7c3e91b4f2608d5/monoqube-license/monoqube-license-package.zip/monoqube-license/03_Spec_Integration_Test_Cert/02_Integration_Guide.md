# Integration Guide: API and SDK (v0.9 draft)

## 1. Interfaces

| Interface | Where | Auth | Purpose |
|---|---|---|---|
| Device REST | On module, management port | mTLS 1.3, client cert issued by site CA | Status, records, AR install, checkpoints |
| Device MQTT | On module | mTLS 1.3 | Streaming records to the customer collector |
| Authority API | Customer or MonoQube cloud | OAuth 2.0 client credentials + mTLS | Issue, revoke, query authorization records |
| Witness API | MonoQube or third party | mTLS | Countersign checkpoints, return receipts |
| Vault / Reports API | MonoQube cloud or on-prem | OAuth 2.0 | Bundles, usage statements, collateral attestations |
| Webhooks | Customer endpoint | HMAC-SHA256 signature header | Events: gate change, fault, tamper, witness gap |

## 2. Device REST (selected)

```
GET  /v1/status                      -> {pod_id, fw, bays:[{bay, state, device_id, kw}], head:{seq, hash}}
GET  /v1/records?from_seq=&limit=    -> CBOR or JSON array of records
GET  /v1/checkpoints/latest          -> {seq, hash, sig, witness_receipt}
POST /v1/authorizations              <- signed AR (see protocol spec section 5)
DELETE /v1/authorizations/{ar_id}    <- signed revocation
GET  /v1/export?from=&to=            -> evidence bundle (.mqb: records + checkpoints + certs + receipts)
```

## 3. Webhook events

```
{"event":"gate.opened","pod":"POD-0007","bay":3,"device_id":"DEV-8F2A","reason":"AR_EXPIRED","seq":918223,"ts":"2027-03-01T08:00:00Z"}
{"event":"tamper","pod":"POD-0007","source":"lid","seq":918224}
{"event":"witness.gap","pod":"POD-0007","last_receipt_seq":918000,"age_s":620}
```

## 4. Verifier SDK (Python, matches the reference model)

```python
from monoqube.verify import load_bundle, verify

bundle = load_bundle("POD-0007_2027-03.mqb")
report = verify(bundle,
                trust_roots=["monotropic_root.pem"],
                require_witness=True)
print(report.ok, report.first_error)
print(report.energy_kwh_by_device())   # {"DEV-8F2A": 10342.7, ...}
print(report.authorized_hours())       # hours with an AR in force and gate closed
```

The reference implementation of `verify` is `07_Measurements/src/monoqube_ref.py` (function `verify`). Production SDKs (Python, Go, TypeScript) will ship with test vectors in `spec/test-vectors/`.

## 5. Sample operating record output

See `01_Engineering/05_Reference_Implementation.md` section 3 and `07_Measurements/results/`.

## 6. Integration patterns

1. **Lender / lessor:** lender holds the authority role or a co-signing role on ARs; receives monthly evidence bundles and a signed collateral attestation (devices present, hours powered, energy, faults). Gate-open on default only per the credit agreement and applicable law.
2. **Operator billing:** records feed metered billing per device and per tenant; customers verify their own bills with the SDK.
3. **OEM PDU:** licensee embeds MQ-MAC-OEM, drives its own relays through the gate interface, exposes MonoQube endpoints next to its existing SNMP/Redfish.
4. **Regulated AI operator:** records feed log retention (EU AI Act Article 12) as tamper-evident infrastructure logs; the record carries no model or data content.
