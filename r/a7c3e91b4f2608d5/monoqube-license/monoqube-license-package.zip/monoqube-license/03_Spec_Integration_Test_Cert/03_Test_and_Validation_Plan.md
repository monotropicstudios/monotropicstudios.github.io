# Test and Validation Plan

| # | Test | Method | Pass criterion | Status |
|---|---|---|---|---|
| V1 | Ledger tamper detection | 10 attack classes x 1,000 trials on the reference model | 100% detected | PASS (MEASURED, model) |
| V2 | Truncation | Drop tail records with and without witnessed checkpoint | 100% with witness | PASS with witness; 0% without (by design, witness mandatory) |
| V3 | False positives | 200 clean ledgers | 0 | PASS (MEASURED, model) |
| V4 | Payload exposure | Canary scan of all record bytes | 0 payload bytes | PASS (MEASURED, model) |
| V5 | Payload overhead | Payload benchmark with meter on and off | Under 2% on separate core | PASS 1.21% (model); hardware target 0% |
| V6 | Energy accuracy, hardware | Reference power standard, 5 / 10 / 50 / 100 / 120% current, PF 1, 0.5L, 0.8C, 3 temperatures | Within 0.5% of reading | NOT STARTED (needs first build) |
| V7 | Gate function | 10,000 open/close cycles under load; interlock open with firmware hung | Contactor opens within 100 ms of interlock | NOT STARTED |
| V8 | Identity | Swap tag, clone attempt, replay of old challenge | Gate opens and record logs mismatch | NOT STARTED (model logic PASS) |
| V9 | CT bypass | Shunt one CT, neutral imbalance check | Fault record within 2 s | NOT STARTED |
| V10 | Power loss | Pull power at random points 1,000 times | No ledger corruption; chain continuous | NOT STARTED |
| V11 | Time attacks | RTC rollback, NTS spoof | Record flags; monotonic counter holds | NOT STARTED |
| V12 | EMC pre-compliance | Pre-scan for FCC Part 15 Class A | Margin above 6 dB | NOT STARTED |
| V13 | Safety | Dielectric, creepage, temperature rise per UL 61010-1 | Per standard | NOT STARTED (NRTL) |
| V14 | Penetration test | Third-party test of firmware, REST, update path | No high or critical open | NOT STARTED |
| V15 | Pilot acceptance | Field SAT per pilot site | See pilot success metrics | NOT STARTED |
| V16 | Interop | Two independent verifiers (Python, Go) agree on 1,000 bundles | 100% agreement | NOT STARTED |

Reproduce V1 to V5: `07_Measurements/run_all.sh`.
