# Certifications and UL Path

**Status today:** no MonoQube product is listed or certified. Nothing has been submitted to a lab. The cryptographic module chosen for production signing (NXP SE052F) already holds FIPS 140-3 validation (NIST CMVP certificate #5139).

## 1. Standards matrix

| Area | Standard | Applies to | Why | Required or optional |
|---|---|---|---|---|
| Product safety (US/Canada) | UL 61010-1 / CSA C22.2 No. 61010-1 (measurement and control equipment) | MQ-MAC controller | Metering and control device on mains; closest fit for a meter-controller | Required for listing |
| Alternative | UL 62368-1 (ICT equipment) | MQ-RACK if sold as IT equipment | Fits when the module ships inside IT gear | Choose one with the NRTL |
| Panel | UL 508A (industrial control panels) | MQ-MM-30 assembly | Panel shop label is what an AHJ inspects | Required (built by listed panel shop) |
| Switching | UL 60947-4-1 | Contactor | Already listed by its maker (Schneider) | Inherited |
| Modular data center | UL 2755 (Ed. 3-2026) under NEC Article 646 | MQ-POD | NEC 646.4 accepts a listed MDC instead of a full field evaluation ([UL Solutions](https://www.ul.com/services/prefabricated-modular-data-center-testing-and-certification); [ANSI webstore](https://webstore.ansi.org/standards/ul/ul2755ed2026)) | Required for pod |
| Transfer switch | UL 1008 | Pod ATS | Buy a listed ATS | Inherited |
| EMC (US) | FCC Part 15 Subpart B, Class A | All SKUs | Unintentional radiator | Required |
| EMC / safety (EU, UK) | CE / UKCA: EN 61010-1, EN 55032, EN 55035, RED if wireless | All SKUs for EU | Market access | Required for EU sales |
| Cyber (product) | UL 2900-1 / 2900-2-2 (industrial control) or IEC 62443-4-2 with 62443-4-1 process | Firmware and interfaces | Enterprise and utility security review shortcut | Strongly recommended |
| Crypto | FIPS 140-3 | Signing module | Federal buyers and lenders' security teams ask | Met by SE052F (CMVP #5139); product states "uses a FIPS 140-3 validated module" |
| Cloud service | SOC 2 Type I, then Type II | Authority, witness, vault, reports | Enterprise procurement | Required for the hosted service |
| Metrology (optional) | ANSI C12.20 accuracy class 0.5 or IEC 62053-22 | Meter function | Lets records stand as billing-grade evidence | Optional; decide with first lender pilot |
| Defense (optional) | MIL-STD-461 / 810, NIST SP 800-171 | Defense SKU and company | Only for DoD work | Optional |
| Export | EAR Category 5 Part 2 (encryption) classification | Firmware | Crypto in product; likely mass-market or 5A992 path | Counsel to confirm |

## 2. NRTL options (none contacted)

All of these appear on OSHA's NRTL list ([OSHA](https://www.osha.gov/nationally-recognized-testing-laboratory-program/current-list-of-nrtls)): UL Solutions, Intertek (ETL mark), CSA Group, TÜV Rheinland, TÜV SÜD, Bureau Veritas. AHJs accept any NRTL mark for the same standard.

| Option | Strength | Note |
|---|---|---|
| UL Solutions | Highest AHJ recognition; owns UL 2755 and UL 2900 | Typically priced above ETL (see below) |
| Intertek (ETL) | Usually faster and lower cost; published rate card | [Intertek ETL rates 2025 PDF](https://www.intertek.se/siteassets/business-lines/electrical/etl-certification-process/etl-certification-rates-2025_general-information.pdf) |
| TÜV Rheinland / TÜV SÜD | One project for US (NRTL) and EU (CB scheme, CE) | Good if EU sales start early |
| CSA Group | Strong in Canada and industrial controls | |

## 3. Cost and timeline (cited third-party estimates; real numbers need quotes)

| Item | Cited cost | Cited time | Source |
|---|---|---|---|
| UL 508A industrial control panel testing | $8,000 to $25,000 | 6 to 12 weeks | [lanpdt](https://lanpdt.com/why-your-business-needs-flawless-product-development-and-design/) |
| UL 508A panel shop program, first year | about $7,000 to $18,000 | | [merobix](https://www.merobix.com/blog/ul-508a-certification-cost-guide) |
| FCC Part 15B | $3,000 to $7,000 | 2 to 3 weeks | [lanpdt](https://lanpdt.com/why-your-business-needs-flawless-product-development-and-design/) |
| FCC Part 15B (other quotes) | $1,500 to $5,000 | 1 to 4 weeks | [anamor](https://www.anamor.xyz/blog/us-tests-and-certifications-for-electronic-products/) |
| NRTL annual upkeep, UL vs ETL | $15,000 to $30,000 vs $10,000 to $22,000 | yearly | [markready](https://markready.io/compare/ul-vs-etl) |
| UL file maintenance minimum | $1,170 per year | | [markready](https://markready.io/guides/ul-certification) |
| UL 2900 / IEC 62443 cyber evaluation | No public price found | months | Quote required |
| SOC 2 Type I then Type II | No cited figure collected | Type II needs a 3 to 12 month observation window (ASSUMPTION, common practice) | Quote required |

## 4. Program plan and budget

| Step | When (from first build, ASSUMPTION) | Budget (ASSUMPTION built from rows above) |
|---|---|---|
| Pre-compliance EMC and safety review | Weeks 0 to 4 | $8,000 |
| Pilot units: NRTL field evaluation per site (lets pilots run before listing) | Weeks 2 to 8 | $5,000 per site |
| Safety listing (UL 61010-1, ETL or UL) | Weeks 4 to 20 | $45,000 to $90,000 |
| UL 508A panel via listed panel shop | Weeks 4 to 16 | $8,000 to $25,000 |
| FCC Part 15 Class A | Weeks 4 to 8 | $3,000 to $7,000 |
| Cyber (UL 2900-2-2 or IEC 62443-4-2) + pen test | Weeks 8 to 28 | $40,000 (quote required) |
| SOC 2 Type I | Months 3 to 6 | $15,000 (quote required) |
| Total one-time | about 7 months | about $150,000 (used in unit economics) |
| Annual upkeep | yearly | about $22,000 (top of cited ETL range) |

## 5. Site status statement (approved wording draft)

> **Certification:** Not yet listed. The certification program is planned with a Nationally Recognized Testing Laboratory for product safety, FCC Class A emissions, and cybersecurity. Production signing uses a FIPS 140-3 validated security module. Target dates are set from first build.

Once a lab is engaged, replace the last sentence with: "Testing in progress with [lab]. Target listing [month year]." Do not show a mark or say "UL listed" until the certificate is issued.
