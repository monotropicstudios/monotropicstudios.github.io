# Spec Sheet: MonoQube Meter Module MQ-MM-30 (T1) and family

Marking: MEASURED (reference model, 22 Nov 2026), CITED (datasheet or public page), DESIGN TARGET (not yet built), ASSUMPTION.

## MQ-MM-30 Meter Module (controller + power gate, one feeder)

| Parameter | Value | Basis |
|---|---|---|
| Function | Meters, gates, and attests power to one compute bay by device identifier; payload independent | Claims 1, 5, 7 to 12 |
| Feeder rating | Up to 30 kW, 3-phase, 208 to 480 VAC | DESIGN TARGET; contactor LC1D95 AC-1 rating 125 A (CITED, Schneider) |
| Metering AFE | ADE9000, 7 channel, class 0.2 capable | CITED (ADI datasheet) |
| Energy accuracy | Better than 0.5% of reading, 5% to 120% of rated current | DESIGN TARGET; model shows 0.17% mean / 0.62% max with 0.2% gain error (MEASURED, model) |
| Sampling | 1 kHz power samples, 1 s signed checkpoints, interval records 1 s to 15 min configurable | DESIGN TARGET; model at 1 kHz uses about 6% of one core (MEASURED) |
| Identity | Bay tag ATECC608B challenge every 60 s; also RFID, EEPROM, or X.509 device credential | Claim 20; DESIGN TARGET |
| Signing | ECDSA P-384 / SHA-384 inside NXP SE052F (FIPS 140-3, CMVP #5139); ML-DSA-65 dual signing planned | CITED (NIST CMVP) / DESIGN TARGET |
| Record format | Hash-chained deterministic CBOR, MQ-ATTEST v0.9; JSON export | `01_Engineering/02_Protocol_Spec_MQ-ATTEST.md` |
| Tamper evidence | 10,000 / 10,000 edits detected, 0 / 200 false positives; truncation needs witnessed checkpoint | MEASURED (model) |
| Payload visibility | None. 0 payload bytes in 43,423 record bytes | MEASURED (model) |
| Payload overhead | 0 on payload when meter runs on its own MCU (hardware); 1.21% / 4.59% in software model | DESIGN / MEASURED (model) |
| Gate | Two series elements: firmware-driven contactor coil + hardware interlock chain (watchdog, tamper, E-stop) | DESIGN TARGET |
| Gate default on fault | Configurable per AR: hold last state or open; safety interlocks always open | DESIGN TARGET |
| Local storage | 1 Mbit FRAM (ledger head, counters), 128 Mbit flash (about 30 days at 1 s intervals) | CITED parts; DESIGN TARGET sizing |
| Time | RTC with backup, NTS-authenticated network time, SE monotonic counter | DESIGN TARGET |
| Network | 10/100 Ethernet, mTLS 1.3, REST + MQTT; out-of-band management separate from payload network | DESIGN TARGET |
| Sensors | 4 x temperature, accelerometer (tamper, transport), lid switch | CITED parts |
| Power | 24 VDC DIN-rail PSU, about 3 W controller | DESIGN TARGET |
| Mounting | DIN rail inside a UL 508A listed panel | DESIGN TARGET |
| Environment | 0 to 55 °C, 5 to 95% RH non-condensing | DESIGN TARGET |
| Compliance targets | NRTL listing (UL 61010-1 / UL 508A panel), FCC Part 15 Class A, UL 2900-2-2 or IEC 62443-4-2, FIPS 140-3 module inside | See `04_Certifications_and_UL_Path.md` |
| Certification status | Not yet listed. Certification program planned; dates set from first build | Status |

## Product family

| SKU | What | Target buyer |
|---|---|---|
| MQ-MAC-OEM | Controller board only, licensee supplies switching | PDU, busway, rack OEMs |
| MQ-MM-30 | Controller + contactor + CTs in panel, one feeder | Retrofit at operators, lender-mandated fleets |
| MQ-RACK | Metered, gated rack with integrated module | Neoclouds, colo cages |
| MQ-POD | Full modular pod with MonoQube control plane | Edge, defense, energy sites |

Pod design targets (private data room only): 42U IEC 60297 bay, 3 to 30 kW dual-input PDU, UL 1008 ATS, UPS about 15 min, hybrid cooling, EMI shielding above 60 dB, dual-path network plus satellite, under 400 A service (CITED, Technical Volume D26BZ-DV010-0121). Pod listing path is UL 2755 under NEC Article 646.
