# MQ-ATTEST v0.9: Metering and Attestation Protocol

Status: draft specification for licensees, 22 November 2026. The reference model in `07_Measurements/src/monoqube_ref.py` implements suite 0x01 below. Production firmware implements suite 0x02.

## 1. Roles and keys

| Role | Holds | Key / credential | Where it lives |
|---|---|---|---|
| Runtime controller (RC) | Pod Attestation Key (PAK) | ECDSA P-384 (suite 0x02) or Ed25519 (suite 0x01) | Generated inside the secure element, never exported |
| Bay tag (BT) | Device Tag Key (DTK) | ECDSA P-256 | ATECC608B on the device carrier, generated on chip |
| Manufacturing CA (MCA) | Signs pod and tag certificates | ECDSA P-384 | Offline root plus HSM-backed issuing CA at the licensee factory |
| Authorization Authority (AA) | Issues Authorization Records (AR) | ECDSA P-384 | Operator or lender side service; can be the licensee or the customer |
| Checkpoint Witness (W) | Countersigns ledger heads | ECDSA P-384 | Independent service (Monotropic, licensee, auditor, or lender) |
| Verifier (V) | Nothing secret | Public certs only | Anyone |

## 2. Cipher suites

| ID | Signature | Hash | Use |
|---|---|---|---|
| 0x01 | Ed25519 | SHA-256 | Reference model and demos only |
| 0x02 | ECDSA P-384 (FIPS 186-4/5) | SHA-384 | Production. Algorithms are on the SE052F CMVP certificate #5139 approved list |
| 0x03 | ML-DSA-65 (FIPS 204) dual-signed with 0x02 | SHA-384 | Post-quantum migration once a validated module is available. ASSUMPTION: timing depends on vendor module validation |

Ed25519 is **not** in the SE052F approved-algorithm list (CMVP #5139, checked 22 Nov 2026), so FIPS deployments must use 0x02.

## 3. Record format

Production encoding is deterministic CBOR (RFC 8949 section 4.2). The reference model uses canonical JSON (sorted keys, no whitespace). Field names are the same.

Common header on every record:

| Field | Type | Meaning |
|---|---|---|
| `v` | uint | Protocol version (9) |
| `suite` | uint | Cipher suite ID |
| `pod` | tstr | Pod serial, bound to the PAK certificate |
| `seq` | uint | Strictly increasing from 0, persisted in F-RAM and mirrored to the SE monotonic counter at each checkpoint |
| `prev` | bstr | Hash of the previous record (genesis = all zeros) |
| `t_ns` | uint | Wall-clock time from the pod RTC, nanoseconds since Unix epoch |
| `mono` | uint | Monotonic tick counter since boot (detects clock steps) |
| `type` | tstr | One of the types in section 4 |
| `hash` | bstr | H(canonical(record without `hash` and `sig`)) |
| `sig` | bstr | Only on CHECKPOINT and KEY_ROTATE: PAK signature over `hash` |

Records never contain payload data: no file contents, prompts, network payloads, or process names. MEASURED: a 62-second run produced 126 records and 43,423 bytes with zero hits for canary bytes planted in the payload's memory (`07_Measurements/results/overhead_extra.json`).

## 4. Record types

| Type | Body fields | Claim / spec anchor |
|---|---|---|
| BOOT | fw_version, fw_hash, boot_reason, cal_id | Secure boot evidence |
| INSERT / REMOVE | bay, presence | Claim 12 (insertion, removal event) |
| AUTHZ | bay, device (tag cert hash), ar_id, state (authorized / unauthorized), reason | Claims 1, 7, 25, 29 |
| GATE | bay, gate (closed / open), cause | Claims 6, 14 to 17, 27 |
| METER | bay, window_ms, energy_mj, peak_mw, vrms_mv[3], irms_ma[4], pf_milli, n_samples | Claims 7, 12, 19, 22 |
| ENVELOPE_CUTOFF | bay, rule (power, current, temp, duration, window), observed, limit | Spec [0031] to [0033] |
| TAMPER | source (door, accel, enclosure, tag_mismatch, neutral_imbalance), detail | Claim 12 (fault-state), spec [0031] enclosure-access condition |
| FAULT | code, detail | Claim 12 |
| TIME_SYNC | source, offset_ns, auth (NTS / Roughtime) | Timing information |
| CHECKPOINT | count, head, se_counter, witness_receipt_of_prev | Spec [0039], [0077] verifiable summary |
| SESSION_SUMMARY | bay, device, ar_id, start_ns, end_ns, active_s, inactive_s, energy_wh, cutoffs, merkle_root | Claims 10, 11, 21 |
| KEY_ROTATE | new_pak_cert, reason | Key lifecycle |

## 5. Authorization Record (AR)

Issued by the AA and delivered to the RC over the telemetry network or a removable token. Never through the hosted device.

```json
{
  "ar_id": "AR-2026-000123",
  "pod": "MQ-MM-30-000042",
  "bay": 1,
  "device_tag_cert_sha384": "9c1f...e2",
  "device_class": "gpu-server-8x",
  "envelope": {"max_w": 14300, "min_w": 50, "max_inlet_c": 35.0, "max_a_per_phase": 48.0},
  "not_before": "2026-12-01T00:00:00Z",
  "not_after": "2027-03-01T00:00:00Z",
  "max_session_s": 2592000,
  "trust_tier": 2,
  "fail_policy": "open_on_controller_fault",
  "issuer_cert_sha384": "41ab...07",
  "sig": "3066...a1"
}
```

Rules:

1. Neither the tag alone nor the AR alone authorizes power (spec [0031]). Both must match.
2. The RC permits the lesser of the requested and the authorized duration (spec [0031]).
3. `max_w` default for an NVIDIA DGX B200 class server would be its published maximum of about 14.3 kW (CITED: NVIDIA DGX B200 page). The operator sets the real value.
4. `fail_policy` is mandatory. Life-safety codes and the site's electrical design decide whether a controller fault opens or holds the gate. The record always logs which happened.

## 6. Insertion and authorization

1. Presence detect on the bay connector fires INSERT.
2. RC sends a 32-byte random nonce from the SE TRNG to the tag over the bay bus.
3. Tag returns ECDSA P-256 signature over (nonce || pod || bay) and its certificate.
4. RC verifies the tag cert chain to the MCA, checks the signature, finds a valid AR whose `device_tag_cert_sha384` matches, checks window and envelope, and writes AUTHZ.
5. If authorized and the hardware interlock chain is satisfied, RC closes the firmware relay. The contactor closes only if the interlock relay is also closed. RC writes GATE closed.
6. If not authorized, RC writes AUTHZ unauthorized and GATE withheld.

Re-evaluation: the tag challenge repeats every 60 s (configurable) and on any TAMPER interrupt. A failed re-check opens the gate (spec [0003] repeated re-evaluation).

## 7. Metering

- ADE9000 samples at 8 or 32 kSPS internally and provides RMS, active power, and energy registers. RC reads every metering window (default 1,000 ms).
- RC computes energy for the window, peak power, and per-phase RMS, and appends METER.
- Neutral current channel is compared against the vector sum of phase currents. A mismatch above threshold raises TAMPER neutral_imbalance (detects a CT bypass on one phase).
- MEASURED (reference model, modeled sensor): with 0.5% Gaussian noise of reading, 16-bit ADC, 1 kHz sampling, 200 sessions of 60 s, mean absolute energy error 0.0022%, p95 0.0057%. With an added 0.2% standard-deviation gain error per sensor, mean 0.17%, p95 0.52%, max 0.62%. Calibration, not noise, dominates real accuracy. Source: `07_Measurements/results/accuracy*.json`.

## 8. Checkpoints and the witness

- RC writes a CHECKPOINT at least every 1 s and at most every 1,000 records. The SE signs `hash`. The SE monotonic counter is incremented and its value included, so rolling back F-RAM is detectable.
- RC sends the checkpoint (seq, head, sig) to one or more Witnesses. The witness returns a signed receipt over (pod, seq, head, witness_time). RC stores the receipt in the next CHECKPOINT body.
- Why a witness is required: MEASURED tamper suite (1,000 trials each) detected 100% of edits, deletions, insertions, reorders, replays, backdating, and wrong-key forgeries, and 0% of truncation back to an earlier valid checkpoint when no external copy of the last checkpoint existed. With the verifier holding the last witnessed checkpoint, truncation detection was 100%. Source: `07_Measurements/results/tamper.json`.

## 9. Verification algorithm (what any third party runs)

Input: record bundle, PAK certificate chain, MCA root, optional witness receipts.

1. Verify PAK cert chains to the MCA root and is not revoked (CRL or OCSP from the licensee).
2. For i = 0..n-1: check `seq == i`, `prev == hash(i-1)`, recompute `hash`, check `t_ns` non-decreasing unless a TIME_SYNC record explains the step.
3. Verify every `sig` on CHECKPOINT / KEY_ROTATE with the PAK.
4. Last record must be a signed CHECKPOINT.
5. If witness receipts are supplied, check the last witnessed (seq, head) is present and equal in the bundle (rollback / truncation test).
6. Optional: recompute SESSION_SUMMARY totals from METER records and compare.

MEASURED verify throughput in the reference model: 232,800 records per second on one core; Ed25519 verify p50 85.6 microseconds (`07_Measurements/results/throughput.json`, `crypto.json`).

## 10. Export interfaces

- Pull: HTTPS with mutual TLS 1.3, `GET /v1/records?from_seq=&to_seq=` returns a bundle.
- Push: webhook or MQTT of CHECKPOINT and SESSION_SUMMARY.
- File: signed bundle (`.mqb`, CBOR sequence plus certs) for air-gapped sites.
- Details and SDK examples: `03_Spec_Integration_Test_Cert/02_Integration_Guide.md`.

## 11. Open items

- Choose the time authentication method per site (NTS RFC 8915 vs Roughtime). ASSUMPTION: NTS.
- Confirm SE052F supports the needed monotonic counter semantics or move the counter to an MCU secure OTP / RPMB scheme. Needs engineering check.
- Formal CDDL schema for every record type (draft in reference repo plan).
