# Reference Implementation Layout

## 1. What exists today (MEASURED, reproducible)

`07_Measurements/` is a copy of the reference prototype built 22 November 2026 (source: `/workspace/monoqube-mvp-metrics/`).

| Path | What it is |
|---|---|
| `src/monoqube_ref.py` | Software model of the controller: identifier reader (stands in for the bay tag bus), authorization records, power gate state, modeled branch-circuit sensor, hash-chained ledger with Ed25519 signed checkpoints, external verifier |
| `src/bench.py` | Benchmarks: crypto timing, throughput, tamper suite, accuracy vs ground truth, payload overhead and payload exposure |
| `run_all.sh` | Runs every benchmark (about six minutes) and writes `results/*.json` |
| `results/` | Raw results, environment record (`env.json`: Python 3.13.5, cryptography 43.0.0, 8-core Xeon, seed 20261122) |

Headline results (MEASURED, software model, not hardware):

| Metric | Result |
|---|---|
| Tamper attacks detected (10 types x 1,000) | 10,000 / 10,000 |
| Truncation detected with witnessed checkpoint / without | 1,000 / 1,000 and 0 / 1,000 |
| False positives on clean ledgers | 0 / 200 |
| Payload bytes in record (canary scan) | 0 |
| Payload slowdown, meter on other core / same core | 1.21% / 4.59% median |
| Meter CPU at 1 kHz sampling, 1 signed checkpoint/s | about 6% of one core |
| Ed25519 sign / verify p50 | 31.2 / 85.6 microseconds |
| Append rate (hash chain, checkpoint per 1,000) | 220,477 records/s |
| Verify rate | 232,800 records/s |
| Energy error, modeled 0.5% sensor | 0.0022% mean, 0.0095% max |
| Energy error with 0.2% gain error | 0.17% mean, 0.62% max |

## 2. Production repository plan (to be built; layout fixed now so licensees can plan)

```
monoqube/
  firmware/
    boot/            MCUboot config, signing keys (HSM refs only)
    tfm-partition/   attestation service, ledger, authz engine, gate driver, tamper
    ns-app/          metering task, NTS client, REST/MQTT, update agent
    drivers/         ade9000, se052f, atecc608b, fm25v10, w25q128, tmp117, lis2dw12
    cal/             calibration constant format + signer
    tests/           unit tests, HIL scripts
  hardware/
    mq-mac/          schematic, layout, fab notes, BOM (02_BOM is the costed version)
    bay-tag/         tag carrier board
    panel/           UL 508A panel drawings for module + contactor
  services/
    authority/       AR issuance, revocation, policy templates
    witness/         checkpoint countersigning, transparency log
    vault/           bundle storage and index
    reports/         usage statements, collateral attestation, evidence packs
  sdk/
    python/          verifier (port of monoqube_ref.verify), bundle tools
    go/              verifier
    ts/              verifier for browser portals
  spec/
    mq-attest.cddl   record schemas
    test-vectors/    signed sample bundles (good and tampered)
  tools/
    provisioning/    key injection station, tag provisioning
    calibration/     calibration station scripts
```

## 3. Sample operating record (from the reference model)

```
{"pod":"POD-REF-1","seq":1,"type":"meter","bay":1,"device":"DEV-A","energy_mj":174705,"peak_mw":403748,"n":1001,"prev":"e839...d902","hash":"3a32...3f96"}
{"pod":"POD-REF-1","seq":2,"type":"checkpoint","count":2,"hash":"fb20...5f5c","sig":"adb2...df07"}
```

This is a sample audit export. The production format adds the header fields in the protocol spec (version, suite, monotonic tick, witness receipt).

## 4. How to reproduce

```
cd 07_Measurements && ./run_all.sh
```

Requires Python 3.11+ and the `cryptography` package.
