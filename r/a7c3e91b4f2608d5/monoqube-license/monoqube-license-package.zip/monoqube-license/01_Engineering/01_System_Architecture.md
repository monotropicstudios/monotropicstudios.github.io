# MonoQube System Architecture

Version 0.9 (licensee data room), 22 November 2026. Prepared for Monotropic Studios LLC. CONFIDENTIAL.

Marking convention used in every file of this data room:

- **MEASURED** means produced by a repeatable run in `07_Measurements/` (software reference model on a general-purpose server, not production hardware).
- **CITED** means taken from a public page or document named next to it.
- **DESIGN TARGET** means a number the design is built to hit. It has not been tested on hardware.
- **ASSUMPTION** means a working value with no measurement or source yet. Each one needs the studio, counsel, or a quote to close.

## 1. What the system does

MonoQube moves the trust boundary for compute evidence outside the computer being measured. The hosting infrastructure, not the hosted machine, decides whether a machine may receive power, measures the power it draws, and writes a record that the hosted machine cannot edit. This follows the as-filed PCT/US26/39996 (claims 1 and 25, with dependents 5 to 13, 20, 21, 23, 26 to 29).

Three properties define the product:

1. **Gate.** Power reaches a bay only when the runtime controller has verified the device identifier in that bay against a signed authorization record delivered on a channel separate from the device (spec [0030] to [0031]).
2. **Meter.** Voltage and current are sampled on the feeder by pod-side sensors. The device reports nothing that the meter relies on (claims 13, 28).
3. **Record.** Every authorization, gate change, metering window, envelope cut-off, tamper and fault event is appended to a hash-chained operating record and sealed by signed checkpoints from a secure element (claims 7 to 12, 29; spec [0039], [0077]).

What it does not do, stated plainly so no licensee over-reads it: power evidence alone does not prove which algorithm ran or whether a result was correct (as-filed spec [0021]). MonoQube proves which identified hardware was energized, when, for how long, and how much energy it drew, under which authorization.

## 2. Product tiers

| Tier | Name | What it is | Who builds it |
|---|---|---|---|
| T1 | MonoQube Meter Module (MQ-MM-30) | DIN-rail runtime controller (MQ-MAC board) plus a power-gate contactor for one feeder up to about 30 kW at 208 V three-phase, plus one bay identity tag per hosted device | Licensee EMS or Monotropic reference build |
| T2 | Metered rack | T1 module integrated ahead of a standard rack PDU, one module per feeder | PDU, rack, and server OEMs |
| T3 | MonoQube Pod (MQ-POD) | Full 12 x 8 ft electrical-equipment vessel with 42U hardware-agnostic bay, dual-input power, UPS, cooling, EMI shielding, and the T1 control plane (from Monotropic Technical Volume D26BZ-DV010-0121) | Licensed integrator / fabricator |

The beachhead in `06_Wedge_GTM` lands with T1 and T2 because they retrofit into existing racks in days. T3 is the expansion product for sites that need the full vessel.

## 3. Block diagram (T1 Meter Module)

```mermaid
flowchart LR
  subgraph FEED[Feeder 208V 3-ph]
    BRK[Upstream breaker]
  end
  subgraph MM[MonoQube Meter Module]
    direction TB
    CT[3x CT + neutral CT]
    VD[Voltage dividers]
    AFE[ADE9000 metering AFE]
    ISO[ISOW7841 reinforced isolation]
    MCU[STM32H573 runtime controller\nTrustZone secure partition]
    SE[SE052F secure element\nFIPS 140-3 L3\nPod Attestation Key]
    FRAM[F-RAM: counter, ledger head]
    NOR[NOR flash: append-only ledger]
    RTC[RTC 1 ppm]
    WD[External watchdog]
    TMP[Temp sensors x4]
    ACC[Accelerometer]
    DOOR[Door / panel reed sensors]
    ILK[Hardware interlock chain\nAND of: MCU enable, watchdog OK,\ndoors closed, no fault]
    K1[Contactor LC1D95BD\npower gate]
    PHY[Ethernet PHY\ntelemetry network only]
  end
  BAY[Compute bay / rack outlets]
  TAG[Bay identity tag\nATECC608B on device carrier]
  NET[Telemetry network\nseparate from compute network]
  BRK --> K1 --> BAY
  CT --> AFE
  VD --> AFE
  AFE --> ISO --> MCU
  MCU <--> SE
  MCU <--> FRAM
  MCU <--> NOR
  MCU <--> RTC
  TMP --> MCU
  ACC --> MCU
  DOOR --> ILK
  WD --> ILK
  MCU --> ILK --> K1
  TAG -- dedicated bay bus, not the payload --> MCU
  MCU --> PHY --> NET
```

Source file: `diagrams/mm_block.mmd` (SVG rendered alongside).

Design rules enforced by the block structure:

- The hosted device has **no electrical or logical path** to the controller, the metering AFE, the secure element, or the ledger store. The bay tag bus is a separate two-wire bus on the bay connector that terminates at the controller.
- The **telemetry network is physically separate** from the compute network (two NICs, two switches; Technical Volume "Dual-Path Isolation").
- The contactor coil is driven through **two relays in series**: one from firmware, one from the hardware interlock chain. Firmware alone cannot hold power on if a door opens or the watchdog trips.

## 4. System context (fleet view)

```mermaid
flowchart TB
  subgraph SITE[Customer site]
    P1[Meter Module / Pod 1]
    P2[Meter Module / Pod n]
  end
  AA[Authorization Authority\nissues signed authorization records]
  WIT[Checkpoint Witness\ncountersigns ledger heads]
  VER[Verifier SDK\nanyone with public keys]
  CONS[Consumers: lender portal, auditor,\nbilling system, SIEM, DCIM]
  MCA[Manufacturing CA\nHSM-backed, offline root]
  MCA -. issues pod and tag certs .-> P1
  AA -- AR over telemetry net or token --> P1
  P1 -- checkpoints --> WIT
  WIT -- signed receipts --> P1
  P1 -- record bundles --> CONS
  CONS --> VER
  WIT --> VER
```

Source: `diagrams/fleet_context.mmd`.

## 5. Control sequence (insertion to cut-off)

```mermaid
sequenceDiagram
  participant Bay as Bay (presence + tag bus)
  participant Tag as Bay tag (ATECC608B)
  participant C as Runtime controller
  participant SE as Secure element
  participant K as Contactor
  participant M as Metering AFE
  Bay->>C: presence detect (insertion event)
  C->>Tag: challenge nonce (32 bytes)
  Tag-->>C: signature over nonce + tag cert
  C->>C: verify tag cert chain + AR match + envelope + window
  C->>SE: append AUTHZ record, update head
  alt authorized and interlocks OK
    C->>K: close (both relays)
    C->>SE: append GATE closed
    loop every metering window (default 1 s)
      M-->>C: Vrms, Irms, P, E per phase
      C->>SE: append METER, check envelope
    end
    C->>SE: CHECKPOINT (signed) every window or K records
  else not authorized
    C->>SE: append GATE withheld (claims 6, 27)
  end
  Note over C,K: Envelope breach, AR expiry, tag mismatch on re-check, door open, or watchdog trip opens the gate and logs ENVELOPE_CUTOFF / TAMPER
```

Source: `diagrams/control_sequence.mmd`.

## 6. Reference pod (T3) subsystem summary

From Monotropic Technical Volume D26BZ-DV010-0121 (June 2026). All values are **DESIGN TARGETS** until a prototype is tested.

| Subsystem | Design target |
|---|---|
| Envelope | 12 ft L x 8 ft W, flatbed transportable, forklift / crane interfaces, seismic anchoring to ASCE 7-22 |
| Bay | Single 42U hardware-agnostic bay per IEC 60297; GPU, CPU, FPGA, co-processor inserts as tagged hot-swap modules |
| Power | 3 to 30 kW dual-input, automatic transfer switch (UL 1008), integrated UPS about 15 min at full load, service under 400 A |
| Metering | Circuit-level metering, target accuracy better than +/-1% (Tim's volume); this data room sets a tighter target of +/-0.5% energy, see spec sheet |
| Cooling | Passive plus liquid hybrid, IP54, redundant pumps, closed loop above 95 F |
| Shielding | EMI shielding target above 60 dB (Tim's volume cites TEMPEST posture; no test performed) |
| Network | Dual-path fiber, separate telemetry network, satellite out-of-band backup |
| Crypto | FIPS 140-3 validated module for keys; post-quantum migration path (FIPS 203 / 204) |
| Permitting | One AHJ review (Town of Blacksburg, VA) classified the enclosure as electrical equipment requiring UL listing and an electrical permit; treatment is site-specific (Tim's volume) |

## 7. Why the architecture is hard to copy without a license

- The claims cover the combination of **device-identifier authorization, power gating, and pod-side measurement** in a hosting structure, which is the minimum set needed to make the record independent of the payload. A competitor that drops any one leg loses the independence property.
- Software-only metering (in-guest agents, hypervisor counters, BMC telemetry) sits inside the trust boundary being evaluated (spec [0012], [0018], [0019]). That is the gap the product fills.
- Claim scope is pending and unpublished. See `04_Licensing/03_IP_Status_and_Claim_Coverage.md` for the honest status.
