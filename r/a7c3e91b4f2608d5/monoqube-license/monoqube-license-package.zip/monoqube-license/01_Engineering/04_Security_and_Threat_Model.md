# Security and Threat Model

## 1. Assets

| Asset | Why it matters |
|---|---|
| Operating record integrity | The product is the record. If it can be edited, nothing else matters. |
| Pod Attestation Key (PAK) | Signs checkpoints. Extraction allows forgery. |
| Authorization Records and AA key | Control who gets power. |
| Gate state | Physical control of a financed or regulated asset. |
| Meter accuracy | Billing, collateral and evidence value depend on it. |
| Calibration constants | Altering them skews energy quietly. |

## 2. Adversaries

| Adversary | Goal | Capability assumed |
|---|---|---|
| Tenant / payload operator | Under-report use, run unauthorized hardware, hide activity | Full root on the hosted machine; physical access to the rack front |
| Asset owner / borrower | Hide removal or idling of collateral, inflate utilization for a draw | Physical access to the site, can open doors, can cut power, can image storage |
| Network attacker | Forge or replay records, block exports | On the telemetry network |
| Insider at licensee or Monotropic | Issue rogue certs or ARs | Access to CA or AA systems |
| Supply-chain attacker | Implant firmware or swap components | Access before delivery |

## 3. STRIDE table

| Threat | Example | Control | Residual |
|---|---|---|---|
| Spoofing a device | Clone a bay tag to make an unapproved server look approved | DTK generated and held in ATECC608B, challenge-response every 60 s with fresh nonce | Physical extraction attacks on the tag chip; tag bound to carrier by tamper-evident mount |
| Spoofing a pod | Fake meter emits records | PAK in SE052F (FIPS 140-3 L3, physical L4, CMVP #5139); pod cert chain | Compromise of MCA |
| Tampering with records | Edit energy values | Hash chain + signed checkpoints. MEASURED 100% detection across 10 attack classes x 1,000 trials | None found in model |
| Tampering by truncation | Roll ledger back to an earlier valid checkpoint | Witness receipts + SE monotonic counter. MEASURED 0% detection without witness, 100% with | Requires at least one honest witness |
| Tampering with measurement | Bypass CT on one phase | Neutral-current vs phase-sum check, upstream feeder metering, door sensors | A skilled electrician with the panel open; logged as TAMPER door open first |
| Tampering with calibration | Change gain constants | Constants signed at factory, cal_id in BOOT, verifier pins approved cal_ids | Factory insider |
| Repudiation | Owner says "the meter was down" | BOOT, FAULT, GATE records; UPS-backed controller; last-gasp checkpoint | Total destruction of the module |
| Information disclosure | Records leak workload secrets | Records contain no payload content. MEASURED 0 payload bytes | Power side channels (coarse, 1 s windows); document in customer DPA |
| Denial of service | Kill the telemetry link | Local ledger continues; witness gap is visible; OOB link option | Long outages delay evidence, do not erase it |
| Elevation of privilege | Payload gains control of gate | No path from payload to controller; separate network; hardware interlock | Misconfigured site wiring; covered in install checklist |
| Time manipulation | Backdate sessions | Authenticated time (NTS), monotonic counter, TIME_SYNC logging. MEASURED backdating detection 100% in model | RTC drift if offline for months (1 ppm RTC is about 2.6 s per month) |
| Rogue authorization | Insider issues AR for unapproved hardware | AA keys in HSM, dual control, every AR id logged in AUTHZ and visible to verifier | Collusion |

## 4. Safety versus security

A power gate on IT equipment is a safety-relevant function. Rules:

- The gate never defeats life-safety systems (EPO, fire alarm shunt trip). Those sit upstream and override.
- `fail_policy` in the AR is explicit and logged.
- Remote cut-off for credit or contract reasons is a commercial and legal decision outside the protocol. See `05_FAQ/Licensee_FAQ.md` (remote disablement) and get counsel review before any lender uses it.

## 5. Limits stated plainly

1. Power evidence does not prove which software ran or that outputs are correct (as-filed spec [0021]). Pairing with a trusted workload signal (GPU confidential-computing attestation, TPM quotes) is an integration option, not a claim.
2. The reference model numbers are software results with modeled sensors. Hardware results come from the validation plan.
3. No third-party penetration test has been done yet.
