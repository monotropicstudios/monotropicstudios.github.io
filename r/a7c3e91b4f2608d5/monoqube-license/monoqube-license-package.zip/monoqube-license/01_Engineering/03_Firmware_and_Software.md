# Firmware and Software Components

## 1. Controller firmware (STM32H573, TrustZone)

| Component | Partition | Function | Base (licensee may substitute) |
|---|---|---|---|
| Immutable root of trust | ROM / secure | Verifies the next stage, enforces lifecycle state | ST STiROT or OEMiRoT |
| Secure bootloader | Secure | Verifies signed images, anti-rollback counter, A/B slots | MCUboot (Apache-2.0) |
| Attestation service | Secure (TF-M partition) | Owns the SE session, builds and signs CHECKPOINT and SESSION_SUMMARY, holds ledger head | Trusted Firmware-M (BSD-3) |
| Ledger store | Secure | Append-only log in NOR flash, head and seq in F-RAM, wear leveling, never rewrites a committed page | Monotropic |
| Authorization engine | Secure | Tag challenge, AR verify, envelope rules, duration limits, re-evaluation timer | Monotropic |
| Gate driver | Secure | Drives firmware relay; reads contactor auxiliary contact to confirm actual state; logs mismatch as FAULT | Monotropic |
| Metering task | Non-secure, read-only path into secure | Reads ADE9000 over isolated SPI, computes windows, calibration constants signed at factory | Monotropic + ADI reference |
| Tamper monitor | Secure | Door sensors, accelerometer wake, neutral imbalance, enclosure open | Monotropic |
| Time service | Non-secure | NTS client, RTC discipline, TIME_SYNC records | open-source NTS client |
| Network stack | Non-secure | lwIP, TLS 1.3 (mbedTLS) with keys in SE, REST server, MQTT client | lwIP, Mbed TLS |
| Update agent | Non-secure + bootloader | Pulls signed images, staged install, rollback protection | MCUboot |

Design rules:

1. The hosted device cannot reach any of this. The only external interfaces are the telemetry Ethernet port, the bay tag bus, and a local service port that is disabled after provisioning.
2. The hardware interlock chain (doors, watchdog, fault) can open the gate with the MCU halted. Firmware cannot override it.
3. Every firmware image hash is logged in BOOT. A verifier can reject records produced by an unapproved image.

## 2. Fleet and cloud software

| Service | Function | Notes |
|---|---|---|
| Authorization Authority | Issues and revokes ARs; policy templates (lender, operator, auditor) | Can be self-hosted by the customer; HSM keys |
| Checkpoint Witness | Countersigns ledger heads; append-only transparency log of heads | Multiple witnesses supported; lender can run its own |
| Record Vault | Stores bundles, indexes by pod / bay / device / session | Object storage plus index; no payload data |
| Verifier SDK | Verifies bundles offline | Python (reference exists), Go, TypeScript planned |
| Reports | Usage statements, collateral attestations, evidence packs (SOC 2, EU AI Act Article 12 log support) | PDF + JSON, signed |
| Connectors | Billing (usage events to Stripe Billing, Metronome, Orb), SIEM (syslog / CEF), DCIM (SNMP / Redfish read-only), lender portals (CSV / API) | ASSUMPTION: connector list to be confirmed by pilot partners |

## 3. Manufacturing and provisioning tools

- Key-injection station: asks the SE to generate the PAK internally, reads the CSR, signs with the issuing CA in an HSM, writes the cert back. Private keys never leave the SE.
- Calibration station: compares the module against a reference meter at the test points in `03_Spec_Integration_Test_Cert/03_Test_and_Validation_Plan.md`, writes signed calibration constants, records cal_id.
- Tag provisioning: ATECC608B on each carrier generates its DTK; tag cert issued by the MCA with the device serial and class.

## 4. Licensing of software

Open-source components listed above are permissive licenses (Apache-2.0, BSD-3). The Monotropic components (ledger, authorization engine, attestation service, gate driver, tamper monitor, verifier, witness) are licensed under the patent and software license in `04_Licensing/02_Draft_Term_Sheet.md`. ASSUMPTION: Monotropic retains copyright in the reference firmware once written; licensee gets a source license.
