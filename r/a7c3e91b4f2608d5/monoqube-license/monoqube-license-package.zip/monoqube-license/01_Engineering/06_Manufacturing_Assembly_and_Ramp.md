# Manufacturing, Assembly, and Deployment Ramp (unit 1 to 10,000)

All volumes and dates are ASSUMPTIONS for planning unless marked.

## 1. Build flow for the Meter Module (T1)

1. **PCBA (MQ-MAC):** 6-layer board, IPC-A-610 Class 2 minimum (Class 3 for defense SKUs), isolation slot under the ISOW7841, conformal coat on the mains side. Built by an EMS partner.
2. **Programming and key injection:** in a controlled room. The SE052F generates the Pod Attestation Key internally. The station reads the CSR, the issuing CA in an HSM signs it, the cert is written back. No private key exists outside the chip.
3. **Calibration:** each module is run against a reference power standard at the test points in the validation plan. Gain and phase constants are signed and stored with a cal_id.
4. **Functional test:** gate cycle, tag challenge, tamper inputs, watchdog trip, record export and verify. A failed unit's key is revoked before scrap.
5. **Panel assembly:** controller, contactor, CTs, terminals, and PSU are mounted and wired in a UL 508A listed panel shop so the assembly carries the panel label.
6. **Pack and ship:** tamper-evident seal over the service port, serial and cert fingerprint on the label.

## 2. Ramp plan

| Phase | Units (cumulative) | Timing from funding (ASSUMPTION) | Who builds | Gate to next phase |
|---|---|---|---|---|
| P0 Engineering build | 1 to 5 | Months 0 to 4 | Prototype house (quick-turn PCBA) + in-house assembly | Bench accuracy within target, protocol conformance, pre-compliance EMC scan |
| P1 Pilot fleet | 10 to 25 | Months 4 to 7 | Same, with NRTL field evaluation per site | 3 pilots live, success metrics met, design freeze |
| P2 Listed product | 100 | Months 7 to 12 | EMS partner, low-volume line; UL 508A panel shop | NRTL listing, FCC Part 15 Class A, pen test closed |
| P3 Scale-up | 1,000 | Months 12 to 24 | EMS partner with box build; licensee OEM begins own builds | First royalty-bearing licensee shipping |
| P4 Volume | 10,000 | Months 24 to 48 | Licensee OEM lines (PDU / rack makers) plus EMS second source | Royalty reporting automated from the licensee ledger |

At P3 and beyond the licensing model means most units are built by licensees on their own lines. Monotropic keeps the reference design, test spec, key-injection CA policy, and conformance program.

## 3. Contract manufacturer and assembly options

These are named as candidates with public capabilities. None has been contacted. Quotes are needed.

| Role | Candidates | Why |
|---|---|---|
| Quick-turn prototype PCBA (P0 to P1) | Screaming Circuits (Milwaukie, OR), MacroFab (Houston, TX), PCBWay / JLCPCB (overseas, low cost) | Low minimums, online quoting |
| Low to mid volume EMS with box build (P2 to P3) | Kimball Electronics, Benchmark Electronics, SMTC, Sanmina | Industrial and regulated product lines, US sites |
| UL 508A panel assembly | Any UL 508A listed panel shop near the EMS (UL Product iQ lists them) | Panel label is what the AHJ inspector looks for |
| Volume (P4) | Licensee in-house lines (PDU, rack, server OEMs) or tier-one EMS (Jabil, Flex, Celestica) | Royalty model means licensee builds |

## 4. Supply-chain risks (from the live supplier pages, 22 Nov 2026)

| Part | Observation | Mitigation |
|---|---|---|
| STM32H573ZIT6 (MCU) | 0 in stock at Digi-Key, 360 due 19 May 2027, 52 week factory lead | Buy ahead at P0 funding; qualify NXP i.MX RT1170 or Microchip PIC32CZ as second source; keep firmware HAL portable |
| ISOW7841DWER | 0 in stock, due Feb 2027, 26 week lead | ISOW7841DWE (different packing) or ADuM5401 + ADuM1401 pair |
| RV-3028-C7 RTC | 0 in stock, due May 2027 | MCU internal RTC with VBAT as fallback; Abracon AB1805 |
| TMP117, LIS2DW12, TPS3431 | 0 in stock, due Dec 2026 to Mar 2027 | Substitutes listed by Digi-Key (Bosch BMA456 in stock for the accelerometer); keep footprints compatible |
| ADE9000 | In stock 559, 44 week lead | Buy P0 to P2 needs up front; ADE9078 as pin-compatible lower-cost option |
| CR8350-1000 CT | Non-stock, 20 week lead, qty-1 price only | Quote CR Magnetics direct; second source split-core CTs (Magnelab SCT-0750-100) for retrofit SKUs |
| LC1D95BD contactor | Newark list $715.39, 1 in stock | Biggest cost line. Quote Schneider distribution direct, ABB AF96, Siemens 3RT; allow OEM licensees to use their own switching device |
| SE052F | 9,738 in stock | Hold 12 months of buffer; SE050F (FIPS 140-2) as fallback for non-FIPS customers |
| Tariffs | Digi-Key pages note tariffs may apply on US shipments | Price quotes landed, not ex-works |

## 5. Field install and support model

| Item | Model |
|---|---|
| Install | Licensed electrician installs the panel on the feeder under a normal electrical permit; MonoQube install checklist (wiring, CT orientation, tag pairing, network separation) signed off in the app; site acceptance test writes a signed SAT record into the ledger |
| Time on site | DESIGN TARGET half a day per rack feeder for retrofit (ASSUMPTION, to be measured in pilots) |
| Commissioning | AR issued by the customer's authority; first checkpoint witnessed; verifier run against the SAT bundle |
| Support tiers | Tier 1 licensee or channel partner; Tier 2 Monotropic remote (records, keys, witness); Tier 3 engineering |
| Spares | Swap-in module; keys are per module, so a swap creates a KEY_ROTATE chain link visible to auditors |
| Monitoring | Witness gaps and FAULT records alert the support desk automatically |
| Warranty | PROPOSED 2 years hardware; reserve 2% of price (cited OEM average 1.05%) |

## 6. Pod (T3) build notes

The pod is built by a licensed fabricator or integrator against Monotropic drawings: frame and shell, shielding, insulation, cooling, electrical (panelboard, ATS, UPS), fire detection, and the T1 control plane. Pod listing path is UL 2755 (modular data center) so the AHJ can accept it under NEC Article 646. Pod pricing in this data room is incomplete because shell, cooling, ATS, electrical, fire, and OOB lines are RFQ (see `02_BOM`).
