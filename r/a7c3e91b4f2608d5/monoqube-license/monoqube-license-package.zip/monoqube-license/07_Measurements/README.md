# MonoQube MVP metrics: reference prototype and benchmarks

Run date: 2026-11-22 (PST). Box: Intel Xeon, 8 vCPU, Linux 6.12, Python 3.13.5, cryptography 43.0.0. Seed 20261122.
Reproduce: `./run_all.sh` (about 6 minutes). Raw output: `results/*.json`.

## What the prototype is
`src/monoqube_ref.py` is a software reference model of the runtime metering and attestation path in PCT/US26/39996:
identifier read from a tag reader outside the device, controller-held authorization record, power gate closed only when
authorized, pod-side power measurement, envelope cut-off, a SHA-256 hash-chained operating record, and Ed25519-signed
checkpoints an external verifier can check with only the public key.

It is NOT the production hardware. The controller runs as a separate OS process instead of a separate MCU, and the
power sensor is modeled (Gaussian noise as a fraction of reading, optional gain error, 16-bit quantization). In the
overhead test the "sensor" reads the payload process's CPU counters from /proc (OS side, the payload never writes to it)
and converts them to watts with a fixed model. Real-sensor accuracy needs the first hardware build.

## Tests (src/bench.py, src/bench_extra.py)
| Result file | What it measures | Method |
|---|---|---|
| crypto.json | Ed25519 sign and verify time | 20,000 sign+verify of 32-byte digests, per-op perf_counter_ns, p50/p99 |
| throughput.json | Record append and verify rate, single core | 200,000 meter records, signed checkpoint every 1,000; separate 50,000-record run signing every record; full-chain verify |
| tamper.json | Tamper detection | 2,000-window ledger, signed checkpoint every 100 windows. 12 fault types x 1,000 trials. Attacker can rewrite storage and recompute the SHA-256 chain but lacks the pod key. Plus 200 clean ledgers for false positives |
| accuracy.json | Metered energy vs ground truth | 200 sessions x 60 s at 1 kHz. Load = random steps 200 to 6,000 W plus sine ripple, exact integral computed analytically. Modeled sensor 0.5% noise of reading, 16-bit ADC, 1 s windows |
| accuracy_with_gain_error.json | Same, adding per-session calibration gain error (sd 0.2%) | 100 sessions. Shows calibration dominates error |
| overhead.json | Payload latency overhead and meter CPU | Payload: SHA-256 + SHA3-256 over 32 MB per iteration, pinned to one core. Meter at 1 kHz sampling, 1 Hz signed checkpoints, pinned to another core (or the same core, worst case). 6 interleaved rounds, 78 timed iterations per condition, medians |
| overhead_extra.json | Noise floor and 60 s exposure scan | Baseline vs baseline on the same harness; 62 s metered run, ledger scanned for the 32-byte canary planted in payload data |
