# Pilot Program and LOI Template

## 1. The offer (PROPOSED)

| Item | Design Partner (first 3) | Standard pilot |
|---|---|---|
| Scope | Up to 10 feeders at one site, MQ-MM-30 modules, hosted authority + witness + vault, monthly signed collateral attestation report | Same |
| Duration | 90 days (30 install and baseline, 60 operating) | 90 days |
| Hardware | Loaned, returned or bought at the 10-unit price at the end | Loaned |
| Price | $0 fee; customer pays its own electrician (ASSUMPTION about half a day per feeder) | $25,000, credited 100% against first-year license or subscription |
| Monotropic delivers | Units, install checklist, remote commissioning, day-30 audit export sample, weekly status, final report | Same |
| Customer delivers | Site access, an electrician, a site revenue meter or sub-meter reading for comparison, one technical owner, a lender or finance contact | Same |
| Safety | NRTL field evaluation of pilot units per site before energizing (budgeted ASSUMPTION $5,000 per site) | Same |

## 2. Success metrics (all must be measured, not asserted)

| # | Metric | Target |
|---|---|---|
| S1 | Energy per feeder vs site revenue-grade meter over 60 days | Within 0.5% |
| S2 | Evidence bundles verified by the customer's own run of the open verifier | 100% |
| S3 | Payload data in records | 0 bytes |
| S4 | Unplanned power interruptions caused by MonoQube | 0 |
| S5 | Witness coverage (checkpoints with receipts) | Above 99.9% |
| S6 | Install time per feeder | Under 1 working day |
| S7 | Lender or finance team accepts the monthly attestation as evidence for a draw, covenant, or audit (written confirmation) | Yes |

## 3. Conversion

If S1 to S6 pass and S7 is a yes, the customer may convert within 30 days to: (a) a fleet license (Model A or B) at the tier price, with pilot fees credited, and most-favored-licensee status; or (b) a 12-month subscription at the fleet rate. If any metric fails, Monotropic fixes and re-runs at no charge for 30 days, or the customer walks away with the final report.

## 4. First pilot targets

Three design-partner slots: one GPU operator with financed capacity, one metering OEM, and one lender or arranger. Names are not listed in this data room.

## 5. LOI template (non-binding)

```
LETTER OF INTENT (NON-BINDING)

Date: [date]
From: [Company], [address] ("Company")
To: Monotropic Studios LLC ("Monotropic")

1. Purpose. Company intends to evaluate the MonoQube metering, power
   authorization, and operating-record system ("MonoQube") in a pilot.

2. Pilot. Up to [10] feeders at [site] for [90] days starting on or about
   [date], on the terms in the MonoQube Pilot Program dated [date].
   Fee: [$0 Design Partner / $25,000 credited to license].

3. Success metrics. S1 to S7 as listed in the Pilot Program.

4. Intent to license. If the success metrics are met, Company intends to
   negotiate in good faith a [non-exclusive license / fleet subscription]
   covering approximately [number] [modules / GPUs / sites] at the
   published tier pricing, with pilot fees credited.

5. Contacts. Technical: [name, title]. Commercial: [name, title].
   Finance or lender liaison: [name, title].

6. Confidentiality. Governed by [the NDA dated ___ / a mutual NDA to be
   signed before the pilot starts].

7. Non-binding. Except for section 6, this letter is a statement of intent
   only and creates no obligation to purchase, license, or pay.

Company: ______________________  Monotropic Studios LLC: ______________________
Name / Title / Date              Monotropic Studios / Date
```
