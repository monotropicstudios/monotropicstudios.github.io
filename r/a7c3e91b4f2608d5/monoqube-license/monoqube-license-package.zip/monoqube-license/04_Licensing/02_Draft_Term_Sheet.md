# Draft Term Sheet: MonoQube Patent and Technology License

**DRAFT FOR DISCUSSION. NOT AN OFFER. NON-BINDING except Confidentiality and Governing Law. Requires counsel review before use.**

| Term | Draft |
|---|---|
| Licensor | Monotropic Studios LLC |
| Licensee | [Name] |
| Licensed IP | PCT/US26/39996 and US provisionals 63/857,478 and 63/906,799; all national-phase, continuation, and divisional filings claiming priority to them; MQ-ATTEST protocol specification; MQ-MAC reference design files; firmware source (see Technology below); know-how |
| Technology | Reference design (schematics, layout, BOM), firmware source under a source license, verifier SDKs, test vectors, conformance test suite |
| Grant | [Non-exclusive / Exclusive in Field], worldwide [or Territory], to make, have made, use, sell, offer, import Licensed Products |
| Field (if exclusive) | [e.g. collateral attestation for GPU-backed credit facilities] |
| Licensed Products | Devices or systems that meter, gate, and record power to a compute bay by device identifier as described in the Licensed IP |
| Upfront fee | [$X], credited against first-year royalties if pilot converted |
| Running royalty | Model A: 6% / 5% / 4% of Net Sales by annual unit tier; floor $40/unit; rack or pod base capped at $1,500/rack. Model B: $0.002 per authorized device-hour |
| Service share | 20% of Licensee's revenue from MonoQube-based recurring services |
| Minimum annual royalty | Exclusive only: [$250k year 1, $500k year 2, $1M year 3] |
| Most-favored licensee | First 10 non-exclusive licensees in a tier |
| Reporting | Quarterly; royalty report generated from the device ledgers (the product meters its own royalty base) |
| Audit | Once per year, 30 days notice, licensor pays unless underpayment above 5% |
| Conformance | Products must pass the MonoQube conformance suite to use the mark "MonoQube Verified" |
| Trust root | Licensor or a designated CA operates the device certificate root; Licensee may run an intermediate CA under the policy |
| Improvements | Licensee owns its improvements; grants back a non-exclusive license to protocol-level improvements for interoperability |
| Prosecution | Licensor controls prosecution and pays costs; exclusive licensee may share costs in exchange for input |
| Enforcement | Licensor first right; exclusive licensee second right in Field |
| Warranties | Licensor has the right to grant; no warranty of validity, scope, or non-infringement; application is pending |
| Indemnity | Mutual, capped at fees paid in prior 12 months |
| Term | Life of the last-to-expire licensed patent; technology license 10 years renewable |
| Termination | Material breach uncured in 60 days; insolvency |
| Change of control | Assignable with consent, not unreasonably withheld |
| Export | Each party complies with EAR; licensee responsible for its own classifications |
| Governing law | [Delaware or Virginia] |
| Confidentiality | Binding upon signing |
| Open items for counsel | IP assignment of record; co-founder contributions; SBIR and government-rights review; prior OEM NDA joint-development terms; remote-disablement terms (see FAQ) |
