# IP Status and Claim Coverage

Not legal advice.

## 1. Status

| Item | Fact | Source |
|---|---|---|
| Application | PCT/US26/39996, "Modular Compute Pod with Verifiable Runtime Metering" | PCT filing receipt |
| Filed | 5 August 2026, USPTO as Receiving Office | Same |
| Applicant / inventor | Monotropic Studios LLC / Timothy Daniel Eisel | Same |
| Priority | US provisionals 63/857,478 (5 Aug 2025) and 63/906,799 (28 Oct 2025) | Same |
| Docket | MTROP.P2001WO/00677051 | Same |
| Claims | 29 claims; independents are 1 (pod) and 25 (method) | Application text |
| Published | No. Expected about 5 February 2027 (18 months from earliest priority) | Calculated |
| National phase deadline | About 5 February 2028 (30 months) | Calculated |
| Granted claims | None | |
| Note | "US26039996" is shorthand for the PCT number, not a US patent number | |

## 2. Claim coverage in plain words

| Claim group | Plain words | Who it reaches |
|---|---|---|
| Claim 1 (independent) | A compute pod with a bay that holds a computing device, a power assembly that switches and measures power to it, and a controller that reads the device's identifier, decides whether it is authorized, and only then turns power on | Anyone selling a rack, PDU, or pod that gates power by device identity |
| Claim 25 (independent) | The same steps as a method | Operators running that process |
| Claims 5, 8, 9, 13, 26, 28 | The controller does this without depending on data from the hosted device (payload independent) | The core differentiator; prevents "the server reports its own usage" |
| Claims 7 to 12, 29 | It keeps an operating record of authorization and power | The audit trail product |
| Claims 10, 11, 21 | Authorization for a duration, with stop when time runs out | Leasing, metered hours, collateral |
| Claim 20 | Identifier from RFID, EEPROM, a token, or a cryptographic credential | Covers common identity methods |
| Claim 23 | Exchangeable devices in the bay | Swap-in hardware fleets |

## 3. What the claims do not cover (be candid in diligence)

1. A signed or third-party-verifiable record is not in any claim. "Verifiable" is in the title only. Spec paragraphs [0039] and [0077] describe a cryptographically verifiable summary sent to an external system, so a continuation or amendment can add it before national phase.
2. Pure software agent metering with no bay and no power control is outside claim 1.
3. Spec [0021] says power data alone does not prove which algorithm ran. MonoQube proves which device was powered, when, how much, and under what authorization. It does not prove what code ran.
4. Scope can change in the international search report, written opinion, and national phase examination.

## 4. Recommended IP actions

1. Confirm the assignment from inventor to Monotropic Studios LLC is recorded.
2. File a continuation-style claim set at national phase covering the signed hash-chained record, external witness, and the two-element gate (spec support at [0039], [0077]).
3. Decide national-phase countries by February 2028 (US, EP, JP, KR, CN, TW, IN suggested by where racks and PDUs are made).
4. Register "MonoQube" and "MonoQube Verified" as trademarks for the conformance program.
5. Keep the protocol spec copyrighted and the conformance suite as licensed know-how; this gives licensees a reason to pay even before grant.
