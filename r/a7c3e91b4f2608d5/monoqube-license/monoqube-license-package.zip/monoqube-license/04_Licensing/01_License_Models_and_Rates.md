# License Models and Rates

All rates are PROPOSALS for negotiation. Benchmarks are CITED. Nothing here is a legal opinion.

## 1. Comparables

| Comparable | Rate | What it covers | Source |
|---|---|---|---|
| Arm Armv9 | about 5% of chip ASP | Processor architecture royalty | Arm fiscal Q1 2026 call, via [EE Times](https://www.eetimes.com/armv9-and-css-royalties-drive-growth-in-1bn-arm-q1-earnings/) |
| Arm Compute Subsystems | about 10% of chip ASP | Pre-integrated subsystem, closer to a reference design | Same |
| Arm v8 | about 2.5% to 3.5% | Older architecture | Same |
| Qualcomm 5G handset | 3.25% of device price, royalty base capped at $400 (max about $13 per device) | Essential cellular patents, single-mode 5G | Qualcomm 5G NR licensing statement |
| Avanci 5G Vehicle | $32 per vehicle ($29 early rate) | Pool of cellular SEPs for connected cars | Avanci 5G Vehicle program |
| AWS Bedrock AgentCore | $0.0895 per vCPU-hour | Usage price of a metered agent runtime (shows per-hour metering is accepted by buyers) | AWS AgentCore pricing page |
| GPU rental index, 21 Nov 2026 | H100 $3.37/hr, B200 $8.50/hr | What a metered GPU-hour is worth | gpurentalprices.com |

What the comparables say: hardware IP royalties cluster at 3% to 5% of the device price for architecture-level IP and about 10% when the licensor supplies a working subsystem. Per-unit flat fees (Avanci) work when the device price varies widely. MonoQube supplies a working reference design, firmware, protocol, and conformance program, which sits between Arm architecture and Arm CSS.

## 2. Model options

| Model | Structure | Proposed rate | Best for |
|---|---|---|---|
| A. Per-unit royalty (OEM) | % of net selling price of each licensed product (module, PDU, rack, pod) | 6% (units 1 to 100), 5% (101 to 1,000), 4% (above 1,000); floor $40 per unit; royalty base for a rack or pod is the metering and power-control subassembly, capped at $1,500 per rack (keeps it fair on a $3M rack) | PDU, busway, rack, pod, and server OEMs |
| B. Per-device-hour (operator) | Fee per authorized device-hour recorded in the ledger | $0.002 per GPU-hour (0.02% of a B200 rental hour at $8.50) | Neoclouds, colos, lessors running retrofit modules |
| C. Recurring service share | Share of the licensee's MonoQube-based subscription revenue (witness, vault, reports) | 20% | OEMs that resell the service |
| D. Field-of-use | Exclusive or non-exclusive rights limited to a field, for example "GPU-collateral finance in North America" or "defense tactical edge" | Upfront fee + royalty A or B; exclusivity premium below | Strategic licensees |
| E. Exclusive (field or territory) | Exclusive in a defined field, with minimum annual royalties and diligence milestones | Upfront $500k to $2M (PROPOSED, depends on field) + minimums starting at $250k/yr, stepping up | One anchor partner per field |
| F. Non-exclusive standard | Click-through style standard terms, same rate for all | Model A or B, no upfront above $25k | The ripple: many OEMs, fast |
| G. Acquisition | A purchase of the application family is not offered in this data room. Any terms would be set with counsel. | Not offered here | Strategic acquirer |

## 3. Recommended structure

1. **Non-exclusive standard license (F)** with Model A for OEMs and Model B for operators. Same price for everyone in a tier so the first signers are not undercut. Most-favored-licensee clause for the first 10 licensees.
2. **One exclusive field-of-use (E)** reserved for the first lender or lessor partner who mandates MonoQube in a facility, limited to "collateral attestation services for GPU-backed credit" for 24 months. This is a distribution deal, not a technology lockout. OEMs still sell hardware to everyone.
3. **Pilot conversion credit:** pilot fees credit 100% against the first year of royalties.

## 4. Royalty math examples

| Case | Calculation | Royalty |
|---|---|---|
| OEM ships 1,000 MQ-MAC-OEM boards inside PDUs, PDU metering subassembly priced at $800 | 5% x $800 = $40 (floor) | $40,000 |
| OEM ships 1,000 MQ-MM-30 at $2,600 | 5% x $2,600 | $130,000 |
| Operator: 2,000 GPUs, 90% powered | 2,000 x 8,760 x 0.9 x $0.002 | $31,536 per year |
| Operator: 30,000 GPUs, 90% powered | 30,000 x 8,760 x 0.9 x $0.002 | $473,040 per year |
