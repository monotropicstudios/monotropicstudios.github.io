# Bill of Materials and Unit Cost

Prices are USD from live supplier pages retrieved 22 November 2026 (America/Los_Angeles). Every cited line links its page. Yellow lines in the XLSX are ASSUMPTIONS; RFQ lines are not priced and are excluded from totals.

Files: `MonoQube_BOM.csv`, `MonoQube_BOM.xlsx` (BOM, Rollup with live formulas, Sources), `MonoQube_Unit_Economics.xlsx` (1 / 10 / 100 / 1k / 10k).

## Roll-up per Meter Module (controller + one bay tag + power gate)

| | Qty 1 | Qty 100 | Qty 1,000 |
|---|---|---|---|
| MQ-MAC controller incl. assumption lines | $570.66 | $270.07 | $226.01 |
| of which ASSUMPTION lines (PCB, misc, assembly/test) | $330.00 | $74.00 | $39.00 |
| Power gate contactor (Newark list) | $715.39 | $627.53 | $627.53 |
| **Meter Module total** | **$1,286.05** | **$897.60** | **$853.54** |
| Reference pod infrastructure, cited lines only (rack, PDU, UPS) | $16,122.35 | quote | quote |

The contactor is 73% of the module cost at 1,000 units. It is a list price from one distributor; direct or OEM pricing is the largest cost lever. An OEM licensee that already has a switching device in its PDU only needs the controller (about $226 at 1,000).

## Unit economics by tier

| Units | Module BOM incl. assembly | Certification per unit | Freight | Warranty reserve | Fully loaded cost | Proposed price | Gross margin | Licensee royalty to Monotropic | Margin after royalty |
|---|---|---|---|---|---|---|---|---|---|
| 1 | $1,286.05 | $5,000.00 | $45 | $130.00 | $6,461.05 | $6,500 | 0.6% | $390.00 (6% of net price, floor $40) | -5.4% |
| 10 | $1,106.38 | $1,500.00 | $35 | $98.00 | $2,739.38 | $4,900 | 44.1% | $294.00 (6% of net price, floor $40) | 38.1% |
| 100 | $897.60 | $172.00 | $20 | $68.00 | $1,157.60 | $3,400 | 66.0% | $170.00 (5% of net price, floor $40) | 61.0% |
| 1,000 | $853.54 | $172.00 | $14 | $52.00 | $1,091.54 | $2,600 | 58.0% | $130.00 (5% of net price, floor $40) | 53.0% |
| 10,000 | $840.05 | $17.20 | $10 | $39.00 | $906.25 | $1,950 | 53.5% | $78.00 (4% of net price, floor $40) | 49.5% |

Notes on the table:

- Qty 10 and 10k component prices come from the same Digi-Key / Newark pages (10-piece and reel breaks; where no 10k break exists the highest published break is used). See `_build/unit_econ.py`.
- Certification: units 1 and 10 are pilot units under NRTL field evaluation (ASSUMPTION $5,000 per site and $1,500 per unit). From 100 up, a one-time listing program (ASSUMPTION $150,000, built from cited ranges in `03_Spec_Integration_Test_Cert/04_Certifications.md`) plus one year of upkeep ($22,000, top of the cited ETL range) is spread over the first 1,000 units.
- Freight is an ASSUMPTION pending carrier quotes. Warranty reserve is an ASSUMPTION of 2% of price; the cited 2025 average for US computer OEMs is 1.05% (Warranty Week, 16 July 2026).
- Prices and royalties are PROPOSALS. Unit 1 is effectively break-even because a single hand-built, field-evaluated unit carries its own certification cost. Pilots use loaned units (see `06_Wedge_GTM/05_Pilot_Program_and_LOI.md`).
- Recurring revenue is separate: PROPOSED $150 per module per month for the witness, vault, and reports service.

## Line items

| Line | Assembly | Part | MPN | Supplier | Qty | @1 | @100 | @1k | Basis | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| A1 | MQ-MAC controller | MCU, Cortex-M33 + TrustZone, 2 MB flash, crypto accel (runtime controller) | STM32H573ZIT6 | Digi-Key US 497-STM32H573ZIT6-ND | 1 | $12.25 | $8.14 | $7.48 | cited. 1k uses 720 break. 0 in stock, 360 due 19-May-2027 | [link](https://www.digikey.com/en/products/detail/stmicroelectronics/STM32H573ZIT6/21349059) |
| A2 | MQ-MAC controller | Secure element, FIPS 140-3 L3 (CMVP #5139), pod signing key | SE052F2HN2/Z019HJ | Digi-Key US 568-SE052F2HN2/Z019HJCT-ND | 1 | $6.96 | $4.50 | $4.17 | cited. 1k uses 500 break (CT); 6k T&R $3.79806 | [link](https://www.digikey.com/en/products/detail/nxp-usa-inc/SE052F2HN2-Z019HJ/24374710) |
| A3 | MQ-MAC controller | Polyphase energy metering AFE, class 0.2 capable (ADI spec), 7 ch | ADE9000ACPZ | Digi-Key US 505-ADE9000ACPZ-ND | 1 | $22.49 | $16.09 | $14.69 | cited. 100 uses 57 break; 1k uses 513 break; ADI 1ku list 'from $10.39' | [link](https://www.digikey.com/en/products/detail/analog-devices-inc/ADE9000ACPZ/6708866) |
| A4 | MQ-MAC controller | Reinforced digital isolator with isolated power (mains side AFE to MCU) | ISOW7841DWER | Digi-Key US 296-45475-1-ND | 1 | $13.19 | $8.90 | $8.86 | cited. 1k uses 250 break (CT); 2k T&R $7.97721. 0 in stock, due 09-Feb-2027 | [link](https://www.digikey.com/en/products/detail/texas-instruments/ISOW7841DWER/6820004) |
| A5 | Bay identity tag | Crypto credential on each payload carrier (device identifier, claim 20) | ATECC608B-MAHDA-T | Digi-Key US 150-ATECC608B-MAHDA-TCT-ND | 1 | $0.87 | $0.86 | $0.86 | cited. Only 1 and 25 CT breaks published; 15k T&R $0.70 | [link](https://www.digikey.com/en/products/detail/microchip-technology/ATECC608B-MAHDA-T/13415239) |
| A6 | MQ-MAC controller | RTC, 1 ppm, battery switchover (record timebase) | RV-3028-C7 32.768KHZ 1PPM-TA-QC | Digi-Key US 2195-RV-3028-C732.768KHZ1PPM-TA-QCCT-ND | 1 | $2.41 | $1.46 | $1.35 | cited. 1k uses 1,000 T&R. 0 in stock, due 07-May-2027 | [link](https://www.digikey.com/en/products/detail/micro-crystal-ag/RV-3028-C7-32-768KHZ-1PPM-TA-QC/10431070) |
| A7 | MQ-MAC controller | F-RAM 1 Mbit (monotonic counter, ledger head, last checkpoint) | FM25V10-G | Digi-Key US 448-FM25V10-G-ND | 1 | $18.30 | $15.67 | $14.67 | cited. 100 uses 97 break; 1k uses 582 break | [link](https://www.digikey.com/en/products/detail/infineon-technologies/FM25V10-G/3788992) |
| A8 | MQ-MAC controller | NOR flash 128 Mbit (append-only ledger store) | W25Q128JVSIQ | Digi-Key US W25Q128JVSIQ-ND | 1 | $5.99 | $5.18 | $4.86 | cited. 100 uses 90 break; 1k uses 540 break | [link](https://www.digikey.com/en/products/detail/winbond-electronics/W25Q128JVSIQ/5803943) |
| A9 | MQ-MAC controller | 10/100 Ethernet PHY (telemetry network only) | DP83825IRMQR | Digi-Key US 296-DP83825IRMQRCT-ND | 1 | $1.65 | $0.97 | $0.87 | cited.  | [link](https://www.digikey.com/en/products/detail/texas-instruments/DP83825IRMQR/10715364) |
| A10 | MQ-MAC controller | RJ45 MagJack with magnetics | 0826-1X1T-23-F | Digi-Key US 5923-0826-1X1T-23-F-ND | 1 | $9.23 | $6.66 | $5.76 | cited. 1k uses 800 break | [link](https://www.digikey.com/en/products/detail/bel-fuse-inc/0826-1X1T-23-F/1635089) |
| A11 | MQ-MAC controller | 25 MHz crystal for PHY | ABM8-25.000MHZ-B2-T | Digi-Key US 535-9140-1-ND | 1 | $0.71 | $0.53 | $0.46 | cited.  | [link](https://www.digikey.com/en/products/detail/abracon-llc/ABM8-25-000MHZ-B2-T/675335) |
| A12 | MQ-MAC controller | Temperature sensor +/-0.1 C (bay inlet, outlet, controller, meter) | TMP117AIDRVR | Digi-Key US 296-51834-1-ND | 4 | $6.29 | $4.78 | $4.36 | cited. 0 in stock, due 15-Dec-2026 | [link](https://www.digikey.com/en/products/detail/texas-instruments/TMP117AIDRVR/9685284) |
| A13 | MQ-MAC controller | 3-axis accelerometer (move / shock tamper) | LIS2DW12TR | Digi-Key US 497-17718-1-ND | 1 | $1.79 | $1.30 | $1.14 | cited. 0 in stock, due 30-Dec-2026 | [link](https://www.digikey.com/en/products/detail/stmicroelectronics/LIS2DW12TR/7348326) |
| A14 | MQ-MAC controller | External watchdog (fail-safe gate open on firmware hang) | TPS3431SDRBR | Digi-Key US 296-51909-1-ND | 1 | $2.36 | $1.42 | $1.29 | cited. 0 in stock, due 08-Mar-2027 | [link](https://www.digikey.com/en/products/detail/texas-instruments/TPS3431SDRBR/9597847) |
| A15 | MQ-MAC controller | 24 V to 3.3 V switching regulator module | R-78E3.3-1.0 | Digi-Key US 945-2409-5-ND | 2 | $4.51 | $4.05 | $3.90 | cited. 1k uses 500 break | [link](https://www.digikey.com/en/products/detail/recom-power/R-78E3-3-1-0/5327711) |
| A16 | MQ-MAC controller | Coil-drive relay, 16 A (two in series: MCU gate + hardware interlock chain) | G2RL-1-E DC24 | Digi-Key US Z2835-ND | 2 | $4.06 | $3.22 | $2.87 | cited.  | [link](https://www.digikey.com/en/products/detail/aratas-formerly-omron-components/G2RL-1-E-DC24/368835) |
| A17 | MQ-MAC controller | Current transformer 100 A, 1000:1, solid core (one per phase) | CR8350-1000 | Digi-Key US CR8350-1000-ND | 3 | $16.82 | $16.82 | $16.82 | cited-qty1-only. ASSUMPTION: only a qty-1 price is published; 100/1k set equal to qty-1 until quoted. Non-stock, 20 wk lead | [link](https://www.digikey.com/en/products/detail/cr-magnetics-inc/CR8350-1000/2500065) |
| A18 | MQ-MAC controller | DIN-rail enclosure, PC, UL94 V-0 | 1597DIN9GY | Digi-Key US 164-1597DIN9GY-ND | 1 | $12.64 | $7.74 | $6.99 | cited. 1k uses 500 break | [link](https://www.digikey.com/en/products/detail/hammond-manufacturing/1597DIN9GY/22148069) |
| A19 | MQ-MAC controller | 24 V DIN-rail PSU, 36 W, cULus (controller supply, on UPS-backed circuit) | HDR-30-24 | Digi-Key US 1866-2244-ND | 1 | $15.40 | $13.60 | $13.60 | cited. Highest published break is 25; 100/1k use 25 break | [link](https://www.digikey.com/en/products/detail/mean-well-usa-inc/HDR-30-24/7703799) |
| A20 | MQ-MAC controller | Reed sensor, door / panel open (enclosure-access condition) | 59135-030 | Newark 10M9205 | 2 | $10.83 | $9.46 | $9.27 | cited. 1k uses 250+ break | [link](https://www.newark.com/littelfuse/59135-030/proximity-sensor/dp/10M9205) |
| A21 | MQ-MAC controller | PCB, 6-layer, approx 150 x 85 mm, with isolation slot | MQ-MAC-PCB-r0 | RFQ  | 1 | $45.00 | $12.00 | $6.00 | assumption. ASSUMPTION: no live quote pulled; get PCBWay / JLCPCB / domestic quote | - |
| A22 | MQ-MAC controller | Passives, HV divider resistors, TVS/MOV, fuses, terminal blocks, headers | MQ-MAC-MISC | RFQ  | 1 | $35.00 | $22.00 | $15.00 | assumption. ASSUMPTION: lot estimate until schematic BOM is frozen | - |
| A23 | MQ-MAC controller | SMT assembly, programming, key injection, functional test | MQ-MAC-ASSY | RFQ  | 1 | $250.00 | $40.00 | $18.00 | assumption. ASSUMPTION: EMS quote required | - |
| B1 | Power gate (per 30 kW feeder) | Contactor 3P 95 A AC-3, 24 VDC coil (the claimed power-switching device) | LC1D95BD | Newark 64M2689 | 1 | $715.39 | $627.53 | $627.53 | cited. 100 and 1k use the 50+ break (highest published) | [link](https://www.newark.com/schneider-electric/lc1d95bd/contactor-3pst-no-24vdc-dinrail/dp/64M2689) |
| C1 | Reference pod MQ-POD-10 (10 kW IT) | 42U rack, 600 x 1070 mm | AR3100 | Newark 76K1322 | 1 | $2,799.72 | RFQ | RFQ | cited-qty1-only. Volume: quote | [link](https://www.newark.com/apc/ar3100/rack-cabinet-42u/dp/76K1322) |
| C2 | Reference pod MQ-POD-10 (10 kW IT) | Switched rack PDU 8.6 kW 208 V 3-ph (outlet switching only; MonoQube meter is the record) | AP8965 | CompSource AP8965 | 1 | $2,146.64 | RFQ | RFQ | cited-qty1-only. Volume: quote | [link](https://www.compsource.com/buy/AP8965/Apc-Schneider-37/Switched-Rack-AP8965-24Outlets-86kW-PDU/) |
| C3 | Reference pod MQ-POD-10 (10 kW IT) | Online UPS 10 kVA / 10 kW 208 V (controller and payload ride-through) | SRT10KXLT | CDW 3590610 | 1 | $11,175.99 | RFQ | RFQ | cited-qty1-only. Advertised price; list $17,065 | [link](https://www.cdw.com/product/apc-smart-ups-on-line-10kva-10kw-tower-208v-4x-l6-20r-2x-l6-30r-nema-ou/3590610) |
| C4 | Reference pod MQ-POD-10 (10 kW IT) | Vessel shell 12 x 8 ft: load-rated frame, insulated, EMI-shielded, forklift pockets | MQ-VESSEL | RFQ  | 1 | RFQ | RFQ | RFQ | rfq. Not priced. Needs fabricator quote against drawings | - |
| C5 | Reference pod MQ-POD-10 (10 kW IT) | Closed-loop cooling sized to IT load | MQ-COOL | RFQ  | 1 | RFQ | RFQ | RFQ | rfq. Not priced | - |
| C6 | Reference pod MQ-POD-10 (10 kW IT) | Dual-input transfer switch, UL 1008 | MQ-ATS | RFQ  | 1 | RFQ | RFQ | RFQ | rfq. Not priced | - |
| C7 | Reference pod MQ-POD-10 (10 kW IT) | Panelboard, main breaker, SPD, feeders (UL 67 / UL 508A panel) | MQ-ELEC | RFQ  | 1 | RFQ | RFQ | RFQ | rfq. Not priced | - |
| C8 | Reference pod MQ-POD-10 (10 kW IT) | Fire detection and clean-agent suppression | MQ-FIRE | RFQ  | 1 | RFQ | RFQ | RFQ | rfq. Not priced | - |
| C9 | Reference pod MQ-POD-10 (10 kW IT) | Out-of-band link (LTE-M and optional satellite) | MQ-OOB | RFQ  | 1 | RFQ | RFQ | RFQ | rfq. Not priced | - |

## Excluded from totals

Payload IT hardware, tariffs, NRE, tooling, enclosure shell, cooling, ATS, panelboard, fire suppression, OOB link (pod RFQ lines C4 to C9), and installation labor.

## Why Digi-Key search pages are not linked

Digi-Key and Mouser search pages blocked automated reads from the box on 22 Nov 2026; product detail pages were read through a fetch service. Each link above is the exact product page the price came from.
